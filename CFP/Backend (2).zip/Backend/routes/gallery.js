const express = require('express');
const r = express.Router();
const { Gallery } = require('../models/models');
const { protect, authorize } = require('../middleware/auth');

function toPublicGalleryUrl(req, imageUrl = '') {
  if (!imageUrl) return '';
  if (/^https?:\/\//i.test(imageUrl) || imageUrl.startsWith('data:')) {
    return imageUrl;
  }

  const normalizedPath = imageUrl.startsWith('/') ? imageUrl : `/${imageUrl}`;
  return `${req.protocol}://${req.get('host')}${normalizedPath}`;
}

r.get('/', async (req, res) => {
  try {
    const { category } = req.query;
    const photos = await Gallery.find({ isActive: true, ...(category && category !== 'all' ? { category } : {}) }).sort({ createdAt: -1 });

    const normalizedPhotos = photos.map((photo) => {
      const plainPhoto = typeof photo.toObject === 'function' ? photo.toObject() : { ...photo };
      return {
        ...plainPhoto,
        imageUrl: toPublicGalleryUrl(req, plainPhoto.imageUrl)
      };
    });

    res.json({ success: true, photos: normalizedPhotos });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

r.post('/', protect, authorize('admin'), async (req, res) => {
  const payload = {
    title: String(req.body?.title || '').trim(),
    imageUrl: String(req.body?.imageUrl || '').trim(),
    category: String(req.body?.category || 'gym').trim() || 'gym',
    isActive: req.body?.isActive !== false && req.body?.isActive !== 'false',
    addedBy: req.user.id
  };
  if (!payload.imageUrl) {
    return res.status(400).json({ success: false, message: 'Image URL is required' });
  }
  const photo = await Gallery.create(payload);
  res.status(201).json({ success: true, photo });
});

r.delete('/:id', protect, authorize('admin'), async (req, res) => {
  await Gallery.findByIdAndDelete(req.params.id);
  res.json({ success: true, message: 'Photo deleted' });
});

module.exports = r;
